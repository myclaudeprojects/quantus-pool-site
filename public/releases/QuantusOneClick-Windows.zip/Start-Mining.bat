@echo off
title Quantus One-Click Miner
cd /d "%~dp0"
echo.
echo  Quantus One-Click Miner (Windows)
echo  ---------------------------------
echo  Rewards go to the OPERATOR wormhole address documented in README.md
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start.ps1"
if errorlevel 1 (
  echo.
  echo Start failed. See messages above.
  pause
  exit /b 1
)
echo.
echo Left running in background. Close this window anytime; mining continues.
echo To stop: double-click Stop-Mining.bat
pause

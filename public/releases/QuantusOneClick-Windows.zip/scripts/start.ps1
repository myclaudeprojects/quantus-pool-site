# Quantus One-Click Miner — Start (Windows)
# Starts quantus-node (mainnet validator + miner listen) then quantus-miner.
$ErrorActionPreference = "Stop"

$AppName = "QuantusOneClick"
$InstallRoot = Join-Path $env:LOCALAPPDATA $AppName
$ConfPath = Join-Path $InstallRoot "mining.conf"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Info($msg) { Write-Host "[start] $msg" }

if (-not (Test-Path $ConfPath)) {
  Write-Info "Not installed yet — running install.ps1 first..."
  & (Join-Path $ScriptDir "install.ps1")
}

$conf = @{}
Get-Content $ConfPath | Where-Object { $_ -match "^\s*[^#].*=" } | ForEach-Object {
  $k, $v = $_.Split("=", 2)
  $conf[$k.Trim()] = $v.Trim()
}

$required = @("NODE_NAME","CHAIN","INNER_HASH","CPU_WORKERS","GPU_DEVICES","MINER_LISTEN_PORT","BASE_PATH")
foreach ($k in $required) {
  if (-not $conf.ContainsKey($k) -or [string]::IsNullOrWhiteSpace($conf[$k])) {
    throw "mining.conf missing required key: $k"
  }
}

$BinDir = Join-Path $InstallRoot "bin"
$LogDir = Join-Path $InstallRoot "logs"
$NodeExe = Join-Path $BinDir "quantus-node.exe"
$MinerExe = Join-Path $BinDir "quantus-miner.exe"
$NodeKey = Join-Path $InstallRoot "node_key.p2p"

if (-not (Test-Path $NodeExe)) { throw "Missing $NodeExe — re-run install.ps1" }
if (-not (Test-Path $MinerExe)) { throw "Missing $MinerExe — re-run install.ps1" }
if (-not (Test-Path $NodeKey)) { throw "Missing $NodeKey — re-run install.ps1" }
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }

$wormhole = if ($conf.ContainsKey("WORMHOLE_ADDRESS")) { $conf["WORMHOLE_ADDRESS"] } else { "(see README)" }
Write-Host ""
Write-Host "=== Quantus One-Click Miner — Start ===" -ForegroundColor Cyan
Write-Host "Rewards wormhole (OPERATOR): $wormhole" -ForegroundColor Yellow
Write-Host "Chain: $($conf['CHAIN'])  GPU_DEVICES=$($conf['GPU_DEVICES'])  CPU_WORKERS=$($conf['CPU_WORKERS'])"
Write-Host ""

# --- Node ---
if (Get-Process quantus-node -ErrorAction SilentlyContinue) {
  Write-Info "Node already running"
} else {
  $argsList = @(
    "--name", $conf["NODE_NAME"],
    "--validator",
    "--base-path", $conf["BASE_PATH"],
    "--miner-listen-port", $conf["MINER_LISTEN_PORT"],
    "--chain", $conf["CHAIN"],
    "--node-key-file", $NodeKey,
    "--rewards-inner-hash", $conf["INNER_HASH"],
    "--max-blocks-per-request", "64",
    "--sync", "full"
  )
  $p = Start-Process $NodeExe -ArgumentList $argsList `
    -RedirectStandardOutput (Join-Path $LogDir "node.log") `
    -RedirectStandardError (Join-Path $LogDir "node.err.log") `
    -PassThru -WindowStyle Hidden
  Set-Content (Join-Path $InstallRoot "node.pid") $p.Id
  Write-Info "Node started PID $($p.Id)"

  $token = Join-Path $conf["BASE_PATH"] ("chains\" + $conf["CHAIN"] + "\miner-auth-token")
  Write-Info "Waiting for miner auth token at $token ..."
  $ok = $false
  for ($i = 0; $i -lt 60; $i++) {
    if (Test-Path $token) { $ok = $true; break }
    Start-Sleep -Seconds 2
  }
  if (-not $ok) {
    Write-Warning "miner-auth-token not found yet. Miner may fail until the node finishes starting. Check logs\node.err.log"
  }
}

# --- Miner ---
if (Get-Process quantus-miner -ErrorAction SilentlyContinue) {
  Write-Info "Miner already running"
} else {
  $chainDir = Join-Path $conf["BASE_PATH"] ("chains\" + $conf["CHAIN"])
  $margs = @(
    "serve",
    "--cpu-workers", $conf["CPU_WORKERS"],
    "--gpu-devices", $conf["GPU_DEVICES"],
    "--node-addr", ("127.0.0.1:" + $conf["MINER_LISTEN_PORT"]),
    "--auth-token-file", (Join-Path $chainDir "miner-auth-token"),
    "--tls-cert-sha256-file", (Join-Path $chainDir "miner-tls-cert-sha256")
  )
  $m = Start-Process $MinerExe -ArgumentList $margs `
    -RedirectStandardOutput (Join-Path $LogDir "miner.log") `
    -RedirectStandardError (Join-Path $LogDir "miner.err.log") `
    -PassThru -WindowStyle Hidden
  Set-Content (Join-Path $InstallRoot "miner.pid") $m.Id
  Write-Info "Miner started PID $($m.Id)"
}

Write-Host ""
Write-Host "Stack running. Sync may take a while before useful mining begins." -ForegroundColor Green
Write-Host "Logs: $LogDir"
Write-Host "Stop:  powershell -ExecutionPolicy Bypass -File `"$(Join-Path $ScriptDir 'stop.ps1')`""
Write-Host ""

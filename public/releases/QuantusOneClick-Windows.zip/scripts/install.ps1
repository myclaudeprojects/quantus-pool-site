# Quantus One-Click Miner — Install (Windows)
# Downloads official node + miner binaries and writes mining.conf.
# Rewards are hardcoded to the OPERATOR wormhole address (see README).
$ErrorActionPreference = "Stop"

$AppName = "QuantusOneClick"
$InstallRoot = Join-Path $env:LOCALAPPDATA $AppName
$BinDir = Join-Path $InstallRoot "bin"
$DataDir = Join-Path $InstallRoot "data"
$LogDir = Join-Path $InstallRoot "logs"
$ConfPath = Join-Path $InstallRoot "mining.conf"
$NodeKeyPath = Join-Path $InstallRoot "node_key.p2p"

# Pinned official releases (matching working reference install)
$NodeVersion = "v1.0.2-Qm"
$MinerVersion = "v4.2.0"
$NodeZipUrl = "https://github.com/Quantus-Network/chain/releases/download/$NodeVersion/quantus-node-$NodeVersion-x86_64-pc-windows-msvc.zip"
$MinerExeUrl = "https://github.com/Quantus-Network/quantus-miner/releases/download/$MinerVersion/quantus-miner-windows-x86_64.exe"

# OPERATOR rewards — derives wormhole:
# qzmFDWnWRLygXLQMFU5GrFohBQe4gtFSp5Q45G3tXgn3P9WsQ
# Override with env REWARDS_INNER_HASH if you need a different destination.
$DefaultInnerHash = "0xc1c0bc7d4f547e397208834a358e9db34a03f4acf64ec6668723204bf7bc295f"
$WormholeAddress = "qzmFDWnWRLygXLQMFU5GrFohBQe4gtFSp5Q45G3tXgn3P9WsQ"
$InnerHash = if ($env:REWARDS_INNER_HASH -and $env:REWARDS_INNER_HASH.Trim()) {
  $env:REWARDS_INNER_HASH.Trim()
} else {
  $DefaultInnerHash
}

$CpuWorkers = if ($env:CPU_WORKERS) { $env:CPU_WORKERS } else { "4" }
$GpuDevices = if ($env:GPU_DEVICES) { $env:GPU_DEVICES } else { "1" }
$MinerPort = if ($env:MINER_LISTEN_PORT) { $env:MINER_LISTEN_PORT } else { "9833" }
$NodeName = if ($env:NODE_NAME) { $env:NODE_NAME } else { "$env:COMPUTERNAME-QOC" }

function Write-Info($msg) { Write-Host "[install] $msg" }
function Ensure-Dir($p) { if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null } }

Write-Host ""
Write-Host "=== Quantus One-Click Miner — Install ===" -ForegroundColor Cyan
Write-Host "Install root: $InstallRoot"
Write-Host ""
Write-Host "IMPORTANT: Mining rewards go to the OPERATOR wormhole address:" -ForegroundColor Yellow
Write-Host "  $WormholeAddress" -ForegroundColor Yellow
Write-Host "  (INNER_HASH used by the node; you do not receive rewards to your own wallet.)" -ForegroundColor Yellow
Write-Host ""

Ensure-Dir $InstallRoot
Ensure-Dir $BinDir
Ensure-Dir $DataDir
Ensure-Dir $LogDir

$NodeExe = Join-Path $BinDir "quantus-node.exe"
$MinerExe = Join-Path $BinDir "quantus-miner.exe"

# --- Download node ---
if (-not (Test-Path $NodeExe)) {
  Write-Info "Downloading quantus-node $NodeVersion ..."
  $zipPath = Join-Path $InstallRoot "node.zip"
  Invoke-WebRequest -Uri $NodeZipUrl -OutFile $zipPath -UseBasicParsing
  $extractDir = Join-Path $InstallRoot "_node_extract"
  if (Test-Path $extractDir) { Remove-Item $extractDir -Recurse -Force }
  Expand-Archive -Path $zipPath -DestinationPath $extractDir -Force
  $found = Get-ChildItem -Path $extractDir -Filter "quantus-node.exe" -Recurse | Select-Object -First 1
  if (-not $found) { throw "quantus-node.exe not found inside downloaded zip" }
  Copy-Item $found.FullName $NodeExe -Force
  Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
  Write-Info "Installed $NodeExe"
} else {
  Write-Info "Using existing $NodeExe"
}

# --- Download miner ---
if (-not (Test-Path $MinerExe)) {
  Write-Info "Downloading quantus-miner $MinerVersion ..."
  Invoke-WebRequest -Uri $MinerExeUrl -OutFile $MinerExe -UseBasicParsing
  Write-Info "Installed $MinerExe"
} else {
  Write-Info "Using existing $MinerExe"
}

# --- Node identity (per-machine; not the rewards key) ---
if (-not (Test-Path $NodeKeyPath)) {
  Write-Info "Generating node P2P key at $NodeKeyPath"
  & $NodeExe key generate-node-key --file $NodeKeyPath
  if (-not (Test-Path $NodeKeyPath)) { throw "Failed to create node_key.p2p" }
} else {
  Write-Info "Using existing node_key.p2p"
}

# --- mining.conf ---
$conf = @"
# Quantus One-Click Miner config
# Rewards (wormhole): $WormholeAddress
# DO NOT put seed phrases in this file.
NODE_NAME=$NodeName
CHAIN=mainnet
INNER_HASH=$InnerHash
WORMHOLE_ADDRESS=$WormholeAddress
CPU_WORKERS=$CpuWorkers
GPU_DEVICES=$GpuDevices
MINER_LISTEN_PORT=$MinerPort
NODE_VERSION=$NodeVersion
MINER_VERSION=$MinerVersion
BASE_PATH=$DataDir
"@
Set-Content -Path $ConfPath -Value $conf -Encoding UTF8
Write-Info "Wrote $ConfPath"

Write-Host ""
Write-Host "Install complete." -ForegroundColor Green
Write-Host "Next: run start.ps1  (or Start-Mining.bat)"
Write-Host "Logs: $LogDir"
Write-Host ""

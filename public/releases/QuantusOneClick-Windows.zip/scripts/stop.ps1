# Quantus One-Click Miner — Stop (Windows)
$ErrorActionPreference = "Continue"
Get-Process quantus-miner, quantus-node -ErrorAction SilentlyContinue | Stop-Process -Force
Write-Host "Stopped quantus-node and quantus-miner (if they were running)."
$InstallRoot = Join-Path $env:LOCALAPPDATA "QuantusOneClick"
Remove-Item (Join-Path $InstallRoot "node.pid") -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $InstallRoot "miner.pid") -Force -ErrorAction SilentlyContinue

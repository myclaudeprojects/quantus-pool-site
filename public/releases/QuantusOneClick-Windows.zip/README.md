# Quantus One-Click Miner (Windows)

One-click Windows package that downloads **official** Quantus mainnet binaries and runs a local node + external miner.

**Official docs:** https://docs.quantus.com/guides/mining/

---

## ⚠️ Reward disclosure (read this)

**Mining rewards from this package go to the OPERATOR wormhole address, not to whoever runs the app.**

| Field | Value |
| --- | --- |
| Wormhole (rewards) | `qzmFDWnWRLygXLQMFU5GrFohBQe4gtFSp5Q45G3tXgn3P9WsQ` |
| INNER_HASH (node `--rewards-inner-hash`) | `0xc1c0bc7d4f547e397208834a358e9db34a03f4acf64ec6668723204bf7bc295f` |

If you run this package, you are contributing hash power / bandwidth to that destination. End users **do not** receive QTC to their own wallet unless the operator changes `INNER_HASH` (see below).

This package **never** includes a seed phrase. Only the operator who holds the seed that derives that wormhole can spend rewards.

---

## Quick start (Windows x86_64)

1. Unzip this package anywhere.
2. Double-click **`Start-Mining.bat`**  
   - First run downloads node `v1.0.2-Qm` + miner `v4.2.0` from GitHub Releases into `%LOCALAPPDATA%\QuantusOneClick\`  
   - Generates a local P2P `node_key.p2p` (not related to rewards)  
   - Writes `mining.conf` and starts node + miner in the background
3. To stop: double-click **`Stop-Mining.bat`**

Or from PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\install.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\start.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\stop.ps1
```

### Paths

| What | Where |
| --- | --- |
| Install / config / binaries | `%LOCALAPPDATA%\QuantusOneClick\` |
| Chain data | `%LOCALAPPDATA%\QuantusOneClick\data\` |
| Logs | `%LOCALAPPDATA%\QuantusOneClick\logs\` |

### Defaults

- `CHAIN=mainnet`
- `GPU_DEVICES=1`
- `CPU_WORKERS=4`
- `MINER_LISTEN_PORT=9833` (localhost / firewall — **do not expose UDP 9833 publicly**)

Override at install time via environment variables:

```powershell
$env:GPU_DEVICES = "1"
$env:CPU_WORKERS = "8"
$env:NODE_NAME = "MyRig"
# Optional: mine to a different INNER_HASH (must match a wormhole you control)
$env:REWARDS_INNER_HASH = "0xYOUR_INNER_HASH"
.\scripts\install.ps1
```

---

## What gets downloaded

| Component | Version | Source |
| --- | --- | --- |
| `quantus-node.exe` | `v1.0.2-Qm` | [Quantus-Network/chain](https://github.com/Quantus-Network/chain/releases/tag/v1.0.2-Qm) (`…-x86_64-pc-windows-msvc.zip`) |
| `quantus-miner.exe` | `v4.2.0` | [Quantus-Network/quantus-miner](https://github.com/Quantus-Network/quantus-miner/releases/tag/v4.2.0) (`quantus-miner-windows-x86_64.exe`) |

Node and miner must stay a matching pair (`quantus-miner/2` auth protocol).

---

## Sync note

Wait until the node reaches the mainnet tip before expecting useful rewards. Early/orphan blocks earn nothing. Sync can take from ~15 minutes to a couple of hours depending on disk and network.

Monitor:

- Logs under `%LOCALAPPDATA%\QuantusOneClick\logs\`
- Telemetry: https://telemetry.quantus.cat (find your `NODE_NAME`)
- Local metrics: `http://localhost:9615/metrics`

---

## Security

- **No seed phrases** are shipped or written by this package.
- Do **not** expose miner port **UDP 9833**, RPC **9944**, or metrics **9615** to the public internet. Only P2P **30333** needs outbound/inbound as you choose.
- Treat files under `data\chains\mainnet\miner-auth-token` as secrets on that machine.
- Antivirus / SmartScreen may warn on first download of unsigned GitHub binaries — verify you are pulling from the official Quantus-Network org.

---

## Landing page

`index.html` + `assets/hero.jpg` are a simple download landing page you can host statically. Point the CTA at your hosted zip (update the `href` in `index.html`).

---

## License / attribution

Binaries are © Quantus Network / respective repos. This wrapper is an ops convenience package; it is not an official Quantus product.
